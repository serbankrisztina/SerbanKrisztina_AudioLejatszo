﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Win32;
using System.Windows.Threading;

namespace Audio_lejátszó
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {


        public MediaPlayer mediaPlayer = new MediaPlayer();
        bool gazsi = true;
        public MainWindow()
        {
            
        InitializeComponent();
            pause.Content = "❚ ❚";
            DispatcherTimer timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);   
            timer.Tick += Timer;
            timer.Tick += Timer2;
            timer.Start();

        }

        void Timer(object sender, EventArgs e)  // zeneszám ideje /  hossza
        {
            if ((mediaPlayer.Source != null) && (mediaPlayer.NaturalDuration.HasTimeSpan))  
            {
                idomutato.Content = String.Format("{0} / {1}", mediaPlayer.Position.ToString(@"mm\:ss"), mediaPlayer.NaturalDuration.TimeSpan.ToString(@"mm\:ss")); // labelbe kiirja mennyi idő telt el a zenéből / utána kiirja a zeneszám teljes hosszát
                Progressbar();
                try
                {
                    allithato.Minimum = 0;
                    allithato.Maximum = mediaPlayer.NaturalDuration.TimeSpan.TotalSeconds;
                    allithato.Value = mediaPlayer.Position.TotalSeconds;
                }
                catch (Exception) { }

                
            }
            
        }
        void Timer2(object sender, EventArgs e)
        {
            if (gazsi==false)
            {
                if (allithato.Value == allithato.Maximum)
                {
                    Players();
                }
            }
        }
        private void Select_AudioFile(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Media files (*.mp3;*.mpg;*.mpeg)|*.mp3;*.mpg;*.mpeg|All files (*.*)|*.*";
            if (ofd.ShowDialog() == true)

                mediaPlayer.Open(new Uri(ofd.FileName));
            foreach (string fileN in ofd.FileNames)
                listbox.Items.Add(fileN);
            
        }

        private void Play_Click(object sender, RoutedEventArgs e)
        {
            gazsi = true;
            if (gazsi==true)
            {

            
                if ((listbox.Items.Count > 0) && (listbox.SelectedItem == null))  
                {
                    listbox.SelectedIndex = 0;      
                    Players();
                }
                else if ((listbox.Items.Count > 0) && (listbox.SelectedItem != null)) 
                {
                    Players();
                }
            }
        }

       

        private void Pause_Click(object sender, RoutedEventArgs e)
        {

            if (listbox.Items.Count > 0)
            {
                if (pause.Content == "❚ ❚")
                {
                    mediaPlayer.Pause();
                    pause.FontSize = 20;
                    pause.Padding = new Thickness(0,-5,0,0);
                    pause.Content = "➤";
                }
                else if (pause.Content == "➤")
                {
                    mediaPlayer.Play();
                    pause.Content = "❚ ❚";
                    pause.FontSize = 16;
                    pause.Padding = new Thickness(0, -2, 0, 0);
                }
            }
        }

        private void Stop_Click(object sender, RoutedEventArgs e)
        {
            mediaPlayer.Close();
        }


        public void Players()
        {
            //mediaPlayer.Stop();     
            //mediaPlayer.Close();      
            //allithato.Value = 0;         
            string mediaPath = (listbox.SelectedItem).ToString();
            mediaPlayer.Open(new Uri(mediaPath));
            mediaPlayer.Play();
        }
        private void Progressbar()  // állapotsáv
        {
            try
            {
                sav.Minimum = 0;                                                   
                sav.Maximum = mediaPlayer.NaturalDuration.TimeSpan.TotalSeconds;  
                sav.Value = mediaPlayer.Position.TotalSeconds;        
            }
            catch (Exception) { }
        }

        private void Csuszka_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            mediaPlayer.Volume = (double)csuszka.Value;
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            listbox.Items.Remove(listbox.SelectedItem);
        }

        private void Left_Click(object sender, RoutedEventArgs e)
        {
            if ((listbox.Items.Count > 0) && (listbox.SelectedItem == null))
            {
                listbox.SelectedIndex = listbox.Items.Count - 1;
                Players();
            }
            else if ((listbox.Items.Count > 0) && (listbox.SelectedIndex > 0) && (listbox.SelectedItem != null))
            {
                listbox.SelectedIndex = listbox.SelectedIndex - 1;
                Players();
            }
            else if ((listbox.Items.Count > 0) && (listbox.SelectedIndex == 0) && (csuszka.Value > csuszka.Minimum))
            {
                listbox.SelectedIndex = listbox.Items.Count - 1;
                Players();
            }
        }

        private void Right_Click(object sender, RoutedEventArgs e)
        {
            if (listbox.Items.Count > 0)
            {
                int nextIndex = 0;
                if ((listbox.SelectedIndex >= -1) && (listbox.SelectedIndex < (listbox.Items.Count - 1)))
                    nextIndex = listbox.SelectedIndex + 1;
                listbox.SelectedIndex = nextIndex;
                Players();
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            const string sPath = "save.txt";
            System.IO.StreamWriter SaveFile = new System.IO.StreamWriter(sPath);
            foreach (var item in listbox.Items)
            {
                SaveFile.WriteLine(item);
            }
            SaveFile.Close();
            MessageBox.Show("Successfully saved!");
        }

        private void Restore_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                
                string path = "save.txt";
                string[] readText = File.ReadAllLines(path);
                foreach (string s in readText)
                {
                    listbox.Items.Add(s);
                }
                
            }
            catch (Exception) { }
        }

        private void ClrAll_Click(object sender, RoutedEventArgs e)
        {
            mediaPlayer.Close();
            try
            {
                listbox.Items.Clear();
               
            }
            catch (Exception) { }
        }

        private void Allithato(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            mediaPlayer.Position = TimeSpan.FromSeconds(allithato.Value);
        }

        private void Repeat_Click(object sender, RoutedEventArgs e)
        {
            gazsi = false;
            if (gazsi==false)
            {
                if ((listbox.Items.Count > 0) && (listbox.SelectedItem == null))
                {
                    listbox.SelectedIndex = 0;
                    Players();
                }
                else if ((listbox.Items.Count > 0) && (listbox.SelectedItem != null))
                {
                    Players();
                }
            }
        }

    }
}
